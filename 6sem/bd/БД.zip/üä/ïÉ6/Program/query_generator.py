class QueryGenerator:
    def generate_insert_query(self, table_name, column_names, entries):
            # Формируем строку с названиями столбцов
            columns = ', '.join(column_names)
    
            # Формируем строку со значениями
            values = ', '.join(f"'{entry}'" if entry else 'NULL' for entry in entries)
    
            # Собираем полный запрос
            query = f"INSERT INTO {table_name} ({columns}) VALUES ({values});"
            return query
        

    def generate_delete_query(self, table_name, column_names, entries):
        conditions = ' AND '.join(f"{col} = '{entry}'" for col, entry in zip(column_names, entries) if entry)
        query = f"DELETE FROM {table_name} WHERE {conditions};"
        return query


    def generate_update_query(self, table_name, column_names, old_entries, new_entries):
        set_clauses = []
        for col_name, new_entry in zip(column_names, new_entries):
            if new_entry:
                set_clauses.append(f"{col_name} = '{new_entry}'")

        where_clauses = []
        if len(new_entries) == len(old_entries):
            for col_name, old_entry in zip(column_names, old_entries):
                if old_entry:
                    where_clauses.append(f"{col_name} = '{old_entry}'")
        elif len(new_entries) == len(old_entries) - 1:
            for col_name, old_entry in zip(column_names, old_entries[1:]):
                if old_entry:
                    where_clauses.append(f"{col_name} = '{old_entry}'")

        update_query = f"UPDATE {table_name} SET {', '.join(set_clauses)} WHERE {'AND '.join(where_clauses)}"
        return update_query



