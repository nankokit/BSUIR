queries_list = [
    {
        "id": 1,
        "query": (
            "select films.title, " 
                    "films.year "
            "from films"
        )
    },
    {
        "id": 2,
        "query": (
            "select visitors.name, "
                    "visitors.email "
            "from visitors"
        )
    },
    {
        "id": 3,
        "query": (
            "select * from films "
            "where country in ('USA', 'Canada')"
        )
    },
    {
        "id": 4,
        "query": (
            "select * from visitors "
            "where name like '% Vladislav %'"
        )
    },
    {
        "id": 5,
        "query": (
            "select name, experience "
            "from employees order by experience desc"
        )
    },
    {
        "id": 6,
        "query": (
            "select * from sessions "
            "order by date asc"
        )
    },
    {
        "id": 7,
        "query": (
            "select films.title as title, "
                    "sessions.date as date "
            "from films cross join sessions"
        )
    },
    {
        "id": 8,
        "query": (
            "select halls.id as hall, "
                    "seats.row, "
                    "seats.number "
            "from halls cross join seats"
        )
    },
    {
        "id": 9,
        "query": (
            "select films.title, "
                    "films.id as film_id, "
                    "sessions.date, "
                    "sessions.film_id "
            "from films inner join sessions on (films.id = sessions.film_id)"
        )
    },
    {
        "id": 10,
        "query": (
            "select halls.id as hall, "
                    "sessions.date, "
                    "sessions.hall_id "
            "from halls inner join sessions on (halls.id = sessions.hall_id)"
        )
    },
    {
        "id": 11,
        "query": (
            "select films.id as film, "
                    "films.title, "
                    "sessions.date, "
                    "sessions.film_id "
            "from films left outer join sessions on (films.id = sessions.film_id) "
            "order by films.id"
        )
    },
    {
        "id": 12,
        "query": (
            "select halls.id as hall, "
                    "seats.row, "
                    "seats.number, "
                    "seats.hall_id "
            "from halls left outer join seats on (halls.id = seats.hall_id) "
            "order by halls.id"
        )
    },
    {
        "id": 13,
        "query": (
            "select films.id as film, "
                    "films.title, "
                    "sessions.date, "
                    "sessions.film_id "
            "from films right outer join sessions on (films.id = sessions.film_id) "
            "order by films.id"
        )
    },
    {
        "id": 14,
        "query": (
            "select halls.id as hall, "
                    "seats.row, "
                    "seats.number, "
                    "seats.hall_id "
            "from halls right outer join seats on (halls.id = seats.hall_id) "
            "order by halls.id"
        )
    },
    {
        "id": 15,
        "query": (
            "select films.id as film, "
                    "films.title, "
                    "sessions.date, "
                    "sessions.film_id "
            "from films right outer join sessions on (films.id = sessions.film_id) "
            "order by films.id"
        )
    },
    {
        "id": 16,
        "query": (
            "select halls.id as hall, "
                    "seats.row, "
                    "seats.number, "
                    "seats.hall_id "
            "from halls full outer join seats on (halls.id = seats.hall_id) "
            "order by halls.id"
        )
    },
    {
        "id": 17,
        "query": (
            "select concat(employees.name, ' - ', initcap(employees.post)) as info "
            "from employees"
        )
    },
    {
        "id": 18,
        "query": ( 
            "select round(halls.screen_size) as screen "
            "from halls"
        )
    },
    {
        "id": 19,
        "query": (
            "select halls.type, count(*) "
            "from films "
            "join films_halls on films.id = films_halls.films_id "
            "join halls on halls.id = films_halls.halls_id "
            "group by halls.type"
        )
    },
    {
        "id": 20,
        "query": (
            "select halls.type, count(*) "
            "from halls "
            "join sessions on sessions.hall_id = halls.id and sessions.id in "
            "(select sessions.id from sessions where sessions.date between '2024-03-01' and '2024-03-30') "
            "group by halls.type"
        )
    },
    {
        "id": 21,
        "query": (
            "select employees.post, count(*) "
            "from employees "
            "join employees_sessions on employees.id = employees_sessions.employees_id "
            "join sessions on employees_sessions.session_id = sessions.id "
            "and sessions.date between '2024-04-01' and '2024-04-30' "
            "group by employees.post"
        )
    },
    {
        "id": 22,
        "query": (
            "select * from employees "
            "join employees_sessions on employees.id = employees_sessions.employees_id "
            "join sessions on sessions.id = employees_sessions.session_id "
            "and sessions.film_id in "
            "(select id from films where films.title = 'Home alone 1')"
        )
    },
    {
        "id": 23,
        "query": (
            "select * from visitors "
            "join visitors_sessions on visitors.id = visitors_sessions.visitors_id "
            "join sessions on sessions.id = visitors_sessions.session_id "
            "and sessions.film_id in "
            "(select id from films where films.title = 'Interstellar')"
        )
    },
    {
        "id": 24,
        "query": (
            "select * from visitors "
            "join visitors_seats on visitors_seats.visitors_id = visitors.id "
            "join seats on visitors_seats.seats_id = seats.id "
            "and seats.id in (select seats.id from seats where seats.type = 'VIP')"
        )
    },
    {
        "id": 25,
        "query": (
            "select AVG(price) as average_price "
            "from halls "
            "join sessions on halls.id = sessions.hall_id "
            "join seats on seats.hall_id = halls.id "
            "where seats.type = 'Standart'"
        )
    },
    {
        "id": 26,
        "query": (
            "select min(date) from sessions "
            "join films on sessions.film_id = "
            "(select films.id from films where films.title = 'Home alone 1')"
        )
    },
    {
        "id": 27,
        "query": (
            "select max(duration) from sessions "
            "join films on sessions.film_id in "
            "(select films.id from films where country = 'USA') "
            "join halls on halls.id = sessions.hall_id"
        )
    },
    {
        "id": 28,
        "query": (
            "select sum(price) from sessions "
            "join films on sessions.id in "
            "(select films.id from films where films.country = 'Britain') "
            "join halls on sessions.hall_id = halls.id "
            "and halls.type = 'Standart'"
        )
    },
    {
        "id": 29,
        "query": (
            "select count(*) from visitors "
            "join visitors_sessions on visitors_sessions.visitors_id = visitors.id "
            "join sessions on visitors_sessions.session_id = sessions.id "
            "and sessions.hall_id in (select halls.id from halls where type = 'VIP')"
        )
    },
    {
        "id": 30,
        "query": (
            "select * from halls "
            "where halls.id in (select halls_id from films_halls where films_id = 1) "
            "union "
            "select * from halls "
            "where halls.id in (select halls_id from films_halls where films_id = 2) "
            "union "
            "select * from halls "
            "where halls.id in (select halls_id from films_halls where films_id = 3) "
        )
    },
    {
        "id": 31,
        "query": (
            "select * from halls "
            "where halls.id in (select halls_id from films_halls where films_id = 1) "
            "union all "
            "select * from halls "
            "where halls.id in (select halls_id from films_halls where films_id = 2) "
            "union all "
            "select * from halls "
            "where halls.id in (select halls_id from films_halls where films_id = 3) "
        )
    },
    {
        "id": 32,
        "query": (
            "select name from visitors except "
            "select name from employees "
            "join employees_sessions on employees_sessions.employees_id = employees.id "
            "join sessions on employees_sessions.session_id = sessions.id"
        )
    },
    {
        "id": 33,
        "query": (
            "select name from visitors intersect "
            "select name from employees "
            "join employees_sessions on employees_sessions.employees_id = employees.id "
            "join sessions on employees_sessions.session_id = sessions.id "
        )
    }
]