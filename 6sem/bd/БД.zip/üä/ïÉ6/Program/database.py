import psycopg2
from config import HOST, USER, DB_NAME, PASSWORD
from tkinter import *
from tkinter import ttk
from tkinter import messagebox



class Database():
    connection = None

    def __init__(self):
        self.connection = psycopg2.connect( host=HOST, user=USER, password=PASSWORD, database=DB_NAME)
        self.connection.autocommit = True


    def __del__(self):
        if self.connection != None:
            self.connection.close()
    

    def get_table(self, table_name):
        rows = []
        column_names = []
        with self.connection.cursor() as cursor:
            query = f"SELECT * FROM {table_name};"
            cursor.execute(query)
            rows = cursor.fetchall()
            column_names = [desc[0] for desc in cursor.description]
        return rows, column_names
    
    def execute_query(self, query_str):
        with self.connection.cursor() as cursor:
            query = f"{query_str};"
            cursor.execute(query)
            rows = cursor.fetchall()
            column_names = [desc[0] for desc in cursor.description]
        return rows, column_names