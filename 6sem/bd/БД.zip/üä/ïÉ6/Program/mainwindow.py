from config import TABLE_NAMES
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import query_generator as qgen
from queries import queries_list

EXAMPLES_PATH = "./sql_scripts/examples/"

class MainWindow(Tk):
    def __init__(self, database):
        super().__init__()

        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TButton", background="#333333", foreground="white")
        style.configure("TLabel", background="#333333", foreground="white")
        style.configure("TEntry", fieldbackground="#333333", foreground="white", background="#333333")
        style.configure("TScrollbar", background="#333333")  # Изменение цвета полосы прокрутки
        style.configure(".", background="#333333", foreground="#333333")
        style.configure("Treeview", background="#333333", foreground="#ffffff", fieldbackground="#333333")
        style.configure("Treeview.Heading", background="#333333", foreground="#ffffff", fieldbackground="#333333")
        style.configure('TCombobox', fieldbackground='#444444', foreground='#f1f4d5')

        self.my_db = database
        self.title("Cinema Database")
        self.geometry("1050x750")  # Увеличиваем размер окна в 2 раза
        self.resizable(False, False)
        self.option_add("*tearOff", FALSE)
        self.table_xscrollbar = None 
        self.current_table = 'films'

        self.configure(bg='#333333')
        button_color = '#444444'
        text_color = 'yellow'

        title = Label(self, text="Cinema Database", bg='#333333', fg='yellow', font=("Arial Rounded MT Bold", 48))
        title.pack()

        self.editor = self.create_table(database, "films")
        self.editor.pack(side=LEFT, fill=BOTH, expand=True)  
        self.table_xscrollbar.pack_forget()

        button_frame = Frame(self, bg='#333333')
        button_frame.pack(side=RIGHT, fill=Y)

        for table_name in TABLE_NAMES:
            button = Button(button_frame, text=table_name, command=lambda name=table_name: self.show_table(name), bg=button_color, fg='#f1f4d5', activebackground='#ff8C00', width=20, height=1, font=("Arial", 14))
            button.pack(side=TOP, fill=X)

        self.query_var = StringVar()
        self.query_var.set(f'{queries_list[0]["id"]}) {queries_list[0]["query"]}')  # default value

        query_menu = ttk.Combobox(button_frame, textvariable=self.query_var, values=[f'{q["id"]}) {q["query"]}' for q in queries_list], width=20, style='TCombobox')
        query_menu.pack(side=TOP, fill=X, pady=(50,0))

        # Execute button
        execute_button = Button(button_frame, text="Execute", command=self.execute_query_method, bg='#555555', fg='orange', activebackground='#ff8C00', width=20, height = 1 ,font=("Arial", 14))
        execute_button.pack(side=TOP, fill=X)

        create_button = Button(button_frame, text="Create", command=lambda: self.edit_table("INSERT", self.current_table), bg='#555555', fg='orange', activebackground='#ff8C00', width=20, height=1, font=("Arial", 14))
        create_button.pack(side=TOP, fill=X, pady=(50,0))       
        update_button = Button(button_frame, text="Update", command=lambda: self.edit_table("UPDATE", self.current_table), bg='#555555', fg='orange', activebackground='#ff8C00', width=20,height = 1 ,font=("Arial", 14))
        update_button.pack(side = TOP ,fill=X) 
        delete_button = Button(button_frame, text="Delete", command=lambda: self.edit_table("DELETE", self.current_table), bg ='#555555', fg ='orange', activebackground ='#ff8C00', width =20, height = 1 , font=("Arial", 14))
        delete_button.pack(side = TOP ,fill=X)


    def create_table(self, database, table_name):
        data, column_names = database.get_table(table_name)
        self.table_data = data
        self.column_names = column_names

        table = ttk.Treeview(self, columns=column_names, show="headings", height=20)

        if self.table_xscrollbar:
            self.table_xscrollbar.destroy()
        self.table_xscrollbar = ttk.Scrollbar(self, orient="horizontal", command=table.xview)
        self.table_xscrollbar.pack(side=BOTTOM, fill=X)

        table["xscrollcommand"]=self.table_xscrollbar.set

        if not data:
            label = Label(self, text="No data in the table")
            label.pack()
        else:
            for col in column_names:
                table.heading(col, text=col)
                table.column(col, stretch=True)
        
            for row in data:
                table.insert('', 'end', values=row)
        table.bind('<<TreeviewSelect>>', self.on_select)
        return table


    def on_select(self, event):
        selected_item = event.widget.selection()
        if selected_item:
            self.selected_row = event.widget.item(selected_item)


    def show_table(self, table_name):
        self.editor.pack_forget()
        self.editor = self.create_table(self.my_db, table_name)
        self.editor.pack(side=LEFT, fill=BOTH, expand=True)
        self.current_table = table_name


    def edit_table(self, command, table_name):
        if command == "INSERT":
            self.create_insert_window(table_name)
        elif command == "UPDATE":
            self.create_update_window(table_name)
        elif command == "DELETE" and not hasattr(self, 'selected_row'):
            messagebox.showerror("Error", "No row selected")
        elif command == "DELETE":
            labels = self.column_names
            values = self.selected_row['values']
            self.edit(command, labels, None, values, table_name)
        self.show_table(self.current_table)

    
    def create_insert_window(self, table_name):
        edit_window = Tk()
        edit_window.title("INSERT " + table_name)
        edit_window.geometry("350x350")
        edit_window.configure(bg='#333333')  # Установка цвета фона

        i = 0
        entries = []
        labels = []
        for column_name in self.column_names:
            if column_name == 'id':
                continue
            label = Label(edit_window, text=column_name, bg='#333333', fg='yellow')  # Установка цвета текста и фона
            entry = Entry(edit_window, width=30, bg='#555555', fg='white')  # Установка цвета текста и фона для полей ввода
            entries.append(entry)
            labels.append(label['text'])
            label.grid(row = i, column=0, sticky="e", padx=10, pady=10)
            entry.grid(row = i, column=1, pady=10)
            i += 1
        button = Button(edit_window, text="INSERT", command=lambda: [self.edit("INSERT", labels, None, entries, table_name), edit_window.withdraw()], bg='#555555', fg='orange', activebackground='#ff8C00', width=20, height=1, font=("Arial", 14))
        button.grid(row = i, column=1, pady=10)

    
    def create_update_window(self, table_name):
        if not hasattr(self, 'selected_row'):
            messagebox.showerror("Error", "No row selected")
            return

        edit_window = Tk()
        edit_window.title("UPDATE " + table_name)
        edit_window.geometry("350x350")
        edit_window.configure(bg='#333333')  # Установка цвета фона

        i = 0
        entries = []
        labels = []
        old_values = list(self.selected_row['values'])
        for column_name, old_value in zip(self.column_names, old_values):
            if column_name == 'id':
                continue
            label = Label(edit_window, text=column_name, bg='#333333', fg='yellow')  # Установка цвета текста и фона
            entry = Entry(edit_window, width=30, bg='#555555', fg='white')  # Установка цвета текста и фона для полей ввода
            entry.insert(0, old_value)  # Вставка старого значения в поле ввода
            entries.append(entry)
            labels.append(label['text'])
            label.grid(row = i, column=0, sticky="e", padx=10, pady=10)
            entry.grid(row = i, column=1, pady=10)
            i += 1
        button = Button(edit_window, text="UPDATE", command=lambda: [self.edit("UPDATE", labels, old_values, entries, table_name), edit_window.withdraw()], bg='#555555', fg='orange', activebackground='#ff8C00', width=20, height=1, font=("Arial", 14))
        button.grid(row = i, column=1, pady=10)


    def edit(self, command, labels, old_entries, entries, table_name):
        new_values = []
        if command in ["INSERT", "UPDATE"]:
            for field in entries:
                new_values.append(field.get())
        elif command == "DELETE":
            new_values = [self.selected_row['values'][labels.index(col)] for col in labels]

        print(f"New Values: {new_values}")

        query_generator = qgen.QueryGenerator()

        try:    
            if command == "INSERT":
                query = query_generator.generate_insert_query(table_name, column_names=labels, entries=new_values)
                #print(query)
                with self.my_db.connection.cursor() as cursor:
                    cursor.execute(query)

            elif command == "DELETE":
                query = query_generator.generate_delete_query(table_name, column_names=labels, entries=new_values)
                #print(query)
                with self.my_db.connection.cursor() as cursor:
                    cursor.execute(query)

            elif command == "UPDATE":
                query = query_generator.generate_update_query(table_name, column_names=labels, old_entries=old_entries, new_entries=new_values)
                #print(query)
                with self.my_db.connection.cursor() as cursor:
                    cursor.execute(query)

            self.show_table(self.current_table)
        
        except Exception as _ex:
            messagebox.showerror("Error", f"Wrong {command} query: {_ex}")

    
    def execute_query_method(self):
         selected_query = self.query_var.get()
         query_id = int(selected_query.split(')')[0])  
         query_text = next((q['query'] for q in queries_list if q['id'] == query_id), None)
         
         if query_text:
             self.execute_query(query_id, query_text)


    def execute_query(self, id: int, query: str):
        print(f"Executing Query ID {id}: {query}")

        data, column_names = self.my_db.execute_query(query)
        new_window = Toplevel(self)
        new_window.title(f"Query ID {id} Results")
        new_window.geometry("900x600")  # You can adjust the size as needed
        new_window.configure(bg='#333333')

        # Create a table in the new window to display the results
        table = ttk.Treeview(new_window, columns=column_names, show="headings", height=20)
        table.pack(side=LEFT, fill=BOTH, expand=True)

        # Configure the table
        for col in column_names:
            table.heading(col, text=col)
            table.column(col, stretch=True)

        # Insert the data into the table
        for row in data:
            table.insert('', 'end', values=row)