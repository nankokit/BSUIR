BEGIN;


CREATE TABLE IF NOT EXISTS public.films
(
    id serial,
    title character varying NOT NULL,
    year integer CHECK (year > 1960),
    country character varying,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.halls
(
    id serial,
    type character varying NOT NULL,
    seats_count integer CHECK (seats_count > 0),
    screen_size double precision CHECK (screen_size > 0),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.sessions
(
    id serial,
    price integer NOT NULL CHECK (price > 0),
    date date NOT NULL,
    duration integer CHECK (duration > 0),
    min_age integer DEFAULT 0,
    film_id integer,
    hall_id integer,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.seats
(
    id serial,
    "row" integer CHECK ("row" > 0 AND "row" < 100),
    "number" integer,
    type character varying NOT NULL,
    hall_id integer,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.employees
(
    id serial,
    name character varying CHECK (name != ''),
    post character varying,
    experience integer CHECK (experience >= 0),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.visitors
(
    id serial,
    name character varying CHECK (name != ''),
    age integer,
    email character varying CHECK (email != ''),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.films_halls
(
    films_id integer,
    halls_id integer
);

CREATE TABLE IF NOT EXISTS public.employees_sessions
(
    employees_id integer,
    session_id integer
);

CREATE TABLE IF NOT EXISTS public.visitors_sessions
(
    visitors_id integer,
    session_id integer
);

CREATE TABLE IF NOT EXISTS public.visitors_seats
(
    visitors_id integer,
    seats_id integer
);

ALTER TABLE IF EXISTS public.sessions
    ADD FOREIGN KEY (hall_id)
    REFERENCES public.halls (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.sessions
    ADD FOREIGN KEY (film_id)
    REFERENCES public.films (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.seats
    ADD FOREIGN KEY (hall_id)
    REFERENCES public.halls (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.films_halls
    ADD FOREIGN KEY (films_id)
    REFERENCES public.films (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.films_halls
    ADD FOREIGN KEY (halls_id)
    REFERENCES public.halls (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.employees_sessions
    ADD FOREIGN KEY (employees_id)
    REFERENCES public.employees (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.employees_sessions
    ADD FOREIGN KEY (session_id)
    REFERENCES public.sessions (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.visitors_sessions
    ADD FOREIGN KEY (visitors_id)
    REFERENCES public.visitors (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.visitors_sessions
    ADD FOREIGN KEY (session_id)
    REFERENCES public.sessions (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.visitors_seats
    ADD FOREIGN KEY (visitors_id)
    REFERENCES public.visitors (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.visitors_seats
    ADD FOREIGN KEY (seats_id)
    REFERENCES public.seats (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

END;

-- COMMENT ON TABLE films IS 'Films in cinema';
-- COMMENT ON COLUMN films.id IS 'Film unique key';
-- COMMENT ON COLUMN films.genre IS 'Film genre';
-- COMMENT ON COLUMN films.year IS 'Film creation year';
-- COMMENT ON COLUMN films.country IS 'Country, where film was created';














