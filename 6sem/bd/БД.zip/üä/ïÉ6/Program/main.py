import database as db
import mainwindow as mw
from tkinter import messagebox

#try:
postgresql = db.Database()
if postgresql.connection == None:
    exit()

app = mw.MainWindow(postgresql)
app.mainloop()
