HOST = '127.0.0.1'
USER = 'postgres'
PASSWORD = '123456'
DB_NAME = 'cinema'
TABLE_NAMES = [
    "films",
    "halls",
    "sessions",
    "seats",
    "employees",
    "visitors",
    "films_halls",
    "employees_sessions",
    "visitors_sessions",
    "visitors_seats"
]
