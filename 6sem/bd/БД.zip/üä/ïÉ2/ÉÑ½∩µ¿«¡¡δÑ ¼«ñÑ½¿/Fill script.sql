INSERT INTO film (title, year, country)
VALUES
('The Lord of the Rings', 2002, 'USA'),
('Jurassic World', 2015, 'USA'),
('Interstellar', 2014, 'Canada'),
('Home alone 1', 1990, 'USA'),
('Titanic', 1997, 'Mexico'),
('Ice 1', 2012, 'Russia'),
('Ice 2', 2016, 'Russia'),
('Ice 3', 2023, 'Russia'),
('Ice 1', 2012, 'Russia'),
('Dune', 2022, 'Canada'),
('Fantastic five', 2006, 'USA'),
('Insidious', 2008, 'Britain'),
('Insidious 2', 2012, 'Britain'),
('Insidious 3', 2018, 'Britain'),
('Sinister', 2010, 'USA'),
('Jack Richer', 2012, 'USA'),
('Travelling', 2012, 'Australia'),
('Travelling 2', 2015, 'Australia'),
('The Gods of Egypt', 2016, 'Eagypt'),
('Hunting', 2012, 'Germany'),
('Sea battle', 2012, 'USA'),
('Project X', 2012, 'Russia'),
('Geostorm', 2020, 'USa'),
('Ice 1', 2012, 'Russia'),
('Angry', 2014, 'USA'),
('Seventh son', 2014, 'Italia'),
('Double game', 2014, 'USA'),
('1+1', 2008, 'USA'),
('Lucie', 2014, 'USA'),
('Spider man', 2002, 'USA'),
('Start', 2010, 'Italia');



INSERT INTO hall (type,  seats_count, screen_size)
VALUES
('Standart', 200, 27.2),
('Standart', 160, 27.9),
('VIP', 172, 32.0),
('Standart', 192, 27.2),
('VIP', 180, 27.0),
('Standart', 194, 29.2),
('Standart', 130, 27.1),
('VIP', 172, 32.0),
('Standart', 192, 17.4),
('VIP', 172, 27.0),
('Standart', 140, 37.2),
('Standart', 166, 27.5),
('VIP', 179, 34.0),
('Standart', 192, 27.1),
('VIP', 182, 27.0),
('Standart', 200, 24.2),
('Standart', 160, 21.8),
('VIP', 178, 32.0),
('Standart', 192, 33.1),
('VIP', 180, 27.0),
('Standart', 200, 25.2),
('Standart', 160, 24.9),
('VIP', 168, 32.0),
('Standart', 192, 27.2),
('VIP', 150, 27.0),
('Standart', 200, 27.2),
('Standart', 160, 31.9),
('VIP', 154, 32.0),
('Standart', 182, 30.6),
('VIP', 184, 27.0);




INSERT INTO employee (name, post, experience)
VALUES
('Petrov Vladislav Viacheslavovich', 'manager', 6),
('Mihalovich Tatyana Vladislavovna', 'administrator', 8),
('Barilo Konstantin Sergeevich', 'barmen', 8),
('Kipyatkov Vladislav Ivanovich', 'accountant', 10),
('Manko Alexander Igorevich', 'engineer', 6),
('Dubrovski Konstantin Dmitrievich', 'manager', 6),
('Garashuk Nikita Vasilevich', 'afficiant', 8),
('Bogdanov Roman Sergeevich', 'barmen', 8),
('Shapovaova Anastasia Vladislavovna', 'affician', 10),
('Gil Nikita Alexandrovich', 'engineer', 6),
('Smolenski Nikolai Olegovich', 'manager', 8),
('Kovalchuck Darya Ivanovna', 'manager', 10),
('Chernook Anastasia Yrievna', 'engineer', 5),
('Klimovich Aleksei Nikolaevich', 'barmen', 4),
('Ivanova Anna Sergeevna', 'accountant', 6),
('Stepanyk Oleg Sergeevich', 'accountant', 7),
('Romanovich Valeria Andreevna', 'barmen', 8),
('Gil Dana Andreevna', 'afficiant', 4),
('Borisenko Oleg Fedorovich', 'manager', 10),
('Olehnovich Elizaeta Igorevna', 'security', 2),
('Yaroshuk Victor Valerievich', 'security', 6),
('Kalinin Nikita Anatolievich', 'engineer', 8),
('Guliakevich Valentin Igorevich', 'security', 10),
('Borodin Ivan Ivanovich', 'controller', 2),
('Petrunenko Vladislav Evgenievich', 'barmen', 9),
('Pashenko Margarita Dmitrievna', 'security', 10),
('Voronova Inna Vasilievna', 'barmen', 8),
('Smirnov Andrey Victorovich', 'engineer', 10),
('Bykov Andrey Evgenievich', 'security', 15),
('Barinov Victor Petrovich', 'barmen', 2),
('Smyzin Igor Petrovich', 'accountant', 10);


INSERT INTO visitor (name, age, email)
VALUES
('Petrov Vladislav Viacheslavovich', 20, 'petrov@gmail.com'),
('Mihalovich Tatyana Vladislavovna', 20, 'mihalovich@gmail.com'),
('Barilo Konstantin Sergeevich', 19, 'barilo@gmail.com'),
('Kipyatkov Vladislav Ivanovich', 20, 'kipyatkov@gmail.com'),
('Manko Alexander Igorevich', 20, 'manko@gmail.com'),
('Dubrovski Konstantin Dmitrievich', 20, 'dubrovskiy@gmail.com'),
('Garashuk Nikita Vasilevich', 20, 'garashuk@gmail.com'),
('Bogdanov Roman Sergeevich', 28, 'bogdanov@gmail.com'),
('Shapovaova Anastasia Vladislavovna', 24,'shapovalova@gmail.com'),
('Gil Nikita Alexandrovich', 16, 'gil@gmail.com'),
('Smolenski Nikolai Olegovich', 23, 'smol@gmail.com'),
('Kovalchuck Darya Ivanovna', 19, 'kov@gmail.com'),
('Chernook Anastasia Yrievna', 21, 'chernook@gmail.com'),
('Klimovich Aleksei Nikolaevich', 24, 'klimovich@gmail.com'),
('Ivanova Anna Sergeevna', 32, 'ivanova@gmail.com'),
('Stepanyk Oleg Sergeevich', 12, 'stepanuk@gmail.com'),
('Romanovich Valeria Andreevna', 14, 'roman@gmail.com'),
('Gil Dana Andreevna', 56, 'gilllll@gmail.com'),
('Borisenko Oleg Fedorovich', 32, 'borisenko@gmail.com'),
('Olehnovich Elizaeta Igorevna', 43, 'olehn@gmail.com'),
('Yaroshuk Victor Valerievich', 12, 'yarov@gmail.com'),
('Kalinin Nikita Anatolievich', 40, 'kalinin@gmail.com'),
('Guliakevich Valentin Igorevich', 12, 'gulakevich@gmail.com'),
('Borodin Ivan Ivanovich', 32, 'borodin@gmail.com'),
('Petrunenko Vladislav Evgenievich', 19, 'petrunenko@gmail.com'),
('Pashenko Margarita Dmitrievna', 25, 'pashenko@gmail.com'),
('Voronova Inna Vasilievna', 43, 'voronova@gmail.com'),
('Smirnov Andrey Victorovich', 69, 'smirnov@gmail.com'),
('Bykov Andrey Evgenievich', 51, 'bykov@gmail.com'),
('Barinov Victor Petrovich', 11, 'barinov@gmail.com'),
('Smyzin Igor Petrovich', 27, 'smyzin@gmail.com');


INSERT INTO session (price, date, duration, min_age, film_id, hall_id)
VALUES
(120, '2024-03-12 17:00', 120, 16, 1, 5),
(120, '2024-03-17 22:00', 117, 12, 2, 4),
(120, '2024-04-08 14:20', 143, 16, 3, 3),
(120, '2024-05-01 18:30', 120, 10, 4, 2),
(120, '2024-05-18 17:00', 120, 18, 5, 1),
(120, '2024-05-14 19:30', 130, 10, 4, 2),
(120, '2024-05-15 16:30', 125, 10, 6, 8),
(120, '2024-05-18 12:30', 110, 10, 7, 4),
(120, '2024-05-28 15:30', 159, 10, 18, 9),
(120, '2024-06-13 14:30', 30, 10, 29, 12),
(120, '2024-01-17 13:30', 60, 10, 31, 14),
(120, '2024-08-03 12:30', 172, 10, 12, 29),
(120, '2024-02-03 11:30', 54, 10, 16, 27),
(120, '2024-12-05 22:30', 74, 10, 24, 25),
(120, '2024-10-08 22:30', 321, 10, 14, 21),
(120, '2024-04-01 23:30', 117, 10, 4, 24),
(120, '2024-01-09 17:30', 104, 10, 4, 26),
(120, '2024-02-12 14:30', 128, 10, 9, 27),
(120, '2024-02-23 14:30', 96, 10, 1, 29),
(120, '2024-04-18 13:30', 86, 10, 16, 29),
(120, '2024-04-01 18:30', 90, 10, 17, 12),
(120, '2024-07-03 18:30', 80, 10, 26, 18),
(120, '2024-08-04 17:30', 101, 10, 26, 1),
(120, '2024-08-15 19:30', 116, 10, 14, 5),
(120, '2024-09-12 11:30', 125, 10, 23, 7),
(120, '2024-01-07 12:30', 125, 10, 23, 8),
(120, '2024-05-24 13:30', 125, 10, 27, 1),
(120, '2024-06-24 14:30', 125, 10, 29, 9),
(120, '2024-02-28 11:30', 131, 10, 7, 10),
(120, '2024-12-01 11:30', 120, 10, 4, 2),
(120, '2024-12-07 18:30', 120, 10, 1, 2);


INSERT INTO seat ("row", "number", type, hall_id)
VALUES
(3, 10, 'Standart', 1),
(2, 18, 'Standart', 2),
(7, 3, 'Standart', 3),
(1, 10, 'VIP', 4),
(1, 6, 'VIP', 5),
(3, 11, 'Standart', 1),
(2, 18, 'Standart', 7),
(12, 3, 'Standart', 3),
(1, 17, 'VIP', 4),
(7, 6, 'VIP', 5),
(3, 16, 'Standart', 1),
(2, 28, 'Standart', 4),
(7, 3, 'Standart', 19),
(1, 10, 'VIP', 18),
(1, 2, 'VIP', 5),
(3, 10, 'Standart', 12),
(2, 18, 'Standart', 2),
(4, 3, 'Standart', 15),
(1, 20, 'VIP', 26),
(1, 6, 'VIP', 15),
(3, 10, 'Standart', 19),
(2, 18, 'Standart', 28),
(7, 3, 'Standart', 13),
(18, 10, 'VIP', 14),
(1, 9, 'VIP', 25),
(3, 10, 'Standart', 14),
(2, 18, 'Standart', 23),
(18, 3, 'Standart', 13),
(1, 10, 'VIP', 16),
(21, 6, 'VIP', 12),
(3, 1, 'Standart', 1),
(14, 8, 'Standart', 2),
(7, 31, 'Standart', 24),
(16, 20, 'VIP', 14),
(1, 6, 'VIP', 12);


INSERT INTO public.film_halls_hall(films_id, halls_id)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(1, 2),
(5, 1),
(23, 19),
(14, 4),
(6, 9),
(7, 2),
(1, 7),
(9, 7),
(12, 4),
(3, 13),
(4, 12),
(5, 21),
(2, 5),
(2, 14),
(3, 13),
(4, 12),
(19, 21),
(15, 5),
(23, 24),
(13, 3),
(14, 2),
(17, 21),
(7, 25),
(2, 14),
(5, 30),
(1, 24),
(25, 21);
	
INSERT INTO public.session_employees_employee(employees_id, session_id)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(4, 2),
(5, 1),
(23, 19),
(14, 4),
(6, 9),
(7, 2),
(1, 7),
(9, 7),
(12, 4),
(3, 13),
(4, 12),
(5, 21),
(2, 5),
(2, 14),
(3, 13),
(4, 12),
(19, 21),
(15, 5),
(23, 24),
(13, 3),
(14, 2),
(17, 21),
(7, 25),
(2, 14),
(5, 30),
(1, 24),
(25, 21);

INSERT INTO public.visitor_seats_seat(visitors_id, seats_id)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(4, 2),
(5, 1);

INSERT INTO public.session_visitors_visitor(visitors_id, session_id)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(4, 2),
(5, 1);















