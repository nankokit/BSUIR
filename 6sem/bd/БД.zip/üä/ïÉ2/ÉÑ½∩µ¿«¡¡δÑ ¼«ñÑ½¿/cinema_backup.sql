BEGIN;


CREATE TABLE IF NOT EXISTS public.films
(
    id serial,
    genre character varying NOT NULL,
    year integer CHECK (year > 1960),
    country character varying,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.halls
(
    id serial,
    type character varying NOT NULL,
    seats_count integer CHECK (seats_count > 0),
    screen_size double precision CHECK (screen_size > 0),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.session
(
    id serial,
    price integer NOT NULL CHECK (price > 0),
    date date NOT NULL,
    "time" time without time zone NOT NULL,
    duration integer CHECK (duration > 0),
    min_age integer DEFAULT 0,
    film_id integer,
    hall_id integer,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.seats
(
    id serial,
    "row" integer CHECK ("row" > 0 AND "row" < 100),
    "number" integer,
    type character varying NOT NULL,
    hall_id integer,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.employees
(
    id serial,
    name character varying CHECK (name != ''),
    post character varying,
    experience integer CHECK (experience >= 0),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.visitors
(
    id serial,
    name character varying CHECK (name != ''),
    age integer,
    email character varying CHECK (email != ''),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.films_halls
(
    films_id integer,
    halls_id integer
);

CREATE TABLE IF NOT EXISTS public.employees_session
(
    employees_id integer,
    session_id integer
);

CREATE TABLE IF NOT EXISTS public.visitors_session
(
    visitors_id integer,
    session_id integer
);

CREATE TABLE IF NOT EXISTS public.visitors_seats
(
    visitors_id integer,
    seats_id integer
);

ALTER TABLE IF EXISTS public.session
    ADD FOREIGN KEY (hall_id)
    REFERENCES public.halls (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.session
    ADD FOREIGN KEY (film_id)
    REFERENCES public.films (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.seats
    ADD FOREIGN KEY (hall_id)
    REFERENCES public.halls (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.films_halls
    ADD FOREIGN KEY (films_id)
    REFERENCES public.films (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.films_halls
    ADD FOREIGN KEY (halls_id)
    REFERENCES public.halls (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.employees_session
    ADD FOREIGN KEY (employees_id)
    REFERENCES public.employees (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.employees_session
    ADD FOREIGN KEY (session_id)
    REFERENCES public.session (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.visitors_session
    ADD FOREIGN KEY (visitors_id)
    REFERENCES public.visitors (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.visitors_session
    ADD FOREIGN KEY (session_id)
    REFERENCES public.session (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.visitors_seats
    ADD FOREIGN KEY (visitors_id)
    REFERENCES public.visitors (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;


ALTER TABLE IF EXISTS public.visitors_seats
    ADD FOREIGN KEY (seats_id)
    REFERENCES public.seats (id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION
    NOT VALID;

END;

-- COMMENT ON TABLE films IS 'Films in cinema';
-- COMMENT ON COLUMN films.id IS 'Film unique key';
-- COMMENT ON COLUMN films.genre IS 'Film genre';
-- COMMENT ON COLUMN films.year IS 'Film creation year';
-- COMMENT ON COLUMN films.country IS 'Country, where film was created';



INSERT INTO films (genre, year, country)
VALUES
('The Lord of the Rings', 2002, 'USA'),
('Jurassic World', 2015, 'USA'),
('Interstellar', 2014, 'Canada'),
('Home alone 1', 1990, 'USA'),
('Titanic', 1997, 'Mexico')


INSERT INTO halls (type,  seats_count, screen_size)
VALUES
('Standart', 200, 27.2),
('Standart', 160, 27.9),
('VIP', 172, 32.0),
('Standart', 192, 27.2),
('VIP', 180, 27.0)


INSERT INTO employees (name, post, experience)
VALUES
('Petrov Vladislav Viacheslavovich', 'manager', 6),
('Mihalovich Tatyana Vladislavovna', 'administrator', 8),
('Barilo Konstantin Sergeevich', 'barmen', 8),
('Kipyatkov Vladislav Ivanovich', 'accountant', 10),
('Manko Alexander Igorevich', 'engineer', 6)


INSERT INTO visitors (name, age, email)
VALUES
('Petrov Vladislav Viacheslavovich', 20, 'petrov@gmail.com'),
('Mihalovich Tatyana Vladislavovna', 20, 'mihalovich@gmail.com'),
('Barilo Konstantin Sergeevich', 19, 'barilo@gmail.com'),
('Kipyatkov Vladislav Ivanovich', 20, 'kipyatkov@gmail.com'),
('Manko Alexander Igorevich', 20, 'manko@gmail.com')


INSERT INTO session (price, date, "time", duration, min_age, film_id, hall_id)
VALUES
(120, '2024-03-12', '17:00', 120, 16, 1, 5),
(120, '2024-03-17', '22:00', 117, 12, 2, 4),
(120, '2024-04-08', '14:20', 143, 16, 3, 3),
(120, '2024-05-01', '18:30', 120, 10, 4, 2),
(120, '2024-05-18', '17:00', 120, 18, 5, 1)


INSERT INTO seats ("row", "number", type, hall_id)
VALUES
(3, 10, 'Standart', 1),
(2, 18, 'Standart', 2),
(7, 3, 'Standart', 3),
(1, 10, 'VIP', 4),
(1, 6, 'VIP', 5)


INSERT INTO public.films_halls(films_id, halls_id)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(4, 2),
(5, 1);

INSERT INTO public.employees_session(employees_id, session_id)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(4, 2),
(5, 1);

INSERT INTO public.visitors_seats(visitors_id, seats_id)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(4, 2),
(5, 1);

INSERT INTO public.visitors_session(visitors_id, session_id)
VALUES 
(1, 5),
(2, 4),
(3, 3),
(4, 2),
(5, 1);













