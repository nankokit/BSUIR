-- Test table for lab 3

CREATE TABLE IF NOT EXISTS public.persons
(
	id serial,
	name character varying,
	age integer,
	email character varying,
	PRIMARY KEY(id)
);


INSERT INTO persons (name, age, email)
VALUES 
('John', 35, 'john@gmail.com'),
('Jeremi', 20, 'jeremi@gmail.com'),
('Bernard', 40, 'bernard@gmail.com'),
('Ann', 30, 'ann@gmail.com'),
('Peter', 30, 'peter@gmail.com')


ALTER TABLE persons
RENAME COLUMN email TO email_address;


ALTER TABLE persons
ALTER COLUMN name 
SET NOT NULL;


ALTER TABLE persons
ALTER COLUMN name
DROP NOT NULL;


ALTER TABLE persons
ADD UNIQUE(email_address);


DROP TABLE IF EXISTS persons 















