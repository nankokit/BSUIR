-- select * from films
-- select * from session
select * from halls
-- select * from seats
-- select * from employees
-- select * from visitors